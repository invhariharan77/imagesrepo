control "jboss_1" do
  impact 'critical'
  title "JBoss should not run with root privileges"
  desc "Local OS user ID under which JBoss Ap-plication Server processes run to be checked "
  desc "for 'root','jbsuprt','dat','vas','gpo'. It should not run under any of these ids"

  describe processes("httpd") do
       its('users') { should_not include 'root' }
       its('users') { should_not include 'jbsuprt' }
       its('users') { should_not include 'dat' }
       its('users') { should_not include 'vas' }
       its('users') { should_not include 'gpo' }
  end
 
end
