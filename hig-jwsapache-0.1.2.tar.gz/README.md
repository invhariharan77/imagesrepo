# HIG IBM Red Hat JBoss Application Server InSpec profile

Jboss Application Server Platforms Technical Specification
