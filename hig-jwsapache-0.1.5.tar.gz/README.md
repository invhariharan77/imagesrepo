# HIG IBM Red Hat JWS HTTPD InSpec profile

This technical specification addresses the security control requirements for Web servers. It is intended to provide implementation specifications and guidance for Intel, Unix, Linux, and zOS platforms for the Apache Based Web Servers.  Examples of products are the IBM HTTP Web Server and Oracle Web Server.  This is not an inclusive list.  If the web server is based on Apache directives, this technical specification will be used.
