# copyright: 2018, The Authors

title 'HIG - IBM Red Hat JWS Apache httpd Controls'

apache_app_dir = '/tech/jws/sites'
apache_web_root = '/tech/web'

control 'jwsapache-01' do
  impact 1.0
  title 'Web Server ID - Unique group'
  desc 'An ID which runs the web server'
  tag requirements: 'B - baseline'
  tag section: 'AK.1.7.6'
  tag heading: 'Identify and Authenticate Users'
  tag remediate: 'no'
  tag action: 'Create a new, unique group that the server will run as.'

  describe group('eemgrp') do
    it { should exist }
  end

  describe group('hostmstr') do
    it { should exist }
  end
end

control 'jwsapache-02' do
  impact 1.0
  title 'Web Server ID - Unique user'
  desc 'An ID which runs the web server'
  tag requirements: 'B - baseline'
  tag section: 'AK.1.7.7'
  tag heading: 'Identify and Authenticate Users'
  tag remediate: 'no'
  tag action: 'Create new, unique local userid that the web server will run as, with the default group being the one created above'

  describe user('eemadmin') do
    it { should exist }
    its('group') { should eq 'eemgrp' }
  end

  describe user('hostmstr') do
    it { should exist }
    its('group') { should eq 'hostmstr' }
  end

  describe processes('httpd') do
    its('users') { should include 'eemadmin' }
  end
end

control 'jwsapache-03' do
  impact 1.0
  title 'httpd.conf - enable log module'
  desc 'Enable the Log Config Module. The log_config module provides for flexible logging of client requests, and provides for the configuration of the information in each log.    Rationale: Logging is critical for monitoring usage and potential abuse of your web server.  To configure the web server logging using the log_format directive this module is required.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.2.1'
  tag heading: 'Logging'
  tag remediate: 'update'
  tag action: 'to add LoadModule log_config_module modules/mod_log_config.so'

  describe apache_conf("#{apache_app_dir}/common/conf/modules.conf") do
    its('LoadModule') { should include 'log_config_module /tech/jws/3.0.3/httpd/modules/mod_log_config.so' }
  end
end

control 'jwsapache-04' do
  impact 1.0
  title 'httpd.conf - Run the Apache Web Server as a non-root user'
  desc 'Run the Apache Web Server as a non-root user. Although Apache typically is started with root privileges in order to listen on port 80 and 443, it can and should run as another non-root user in order to perform the web services.  The Apache User and Group directives are used to designate the user and group to be used'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.4.1'
  tag heading: 'System Settings'
  tag remediate: 'update'
  tag action: 'If the Apache user and group do not already exist, create the account and group as a unique system account'

  describe processes('httpd') do
    its('users') { should include 'eemadmin' }
  end

  httpd_conf_list = command("find #{apache_app_dir} -name httpd.conf").stdout.split("\n")
  httpd_conf_list.map do |conf_file|
    describe apache_conf(conf_file) do
      its('User') { should cmp 'eemadmin' }
      its('Group') { should cmp 'eemgrp' }
    end
  end
end

control 'jwsapache-05' do
  impact 1.0
  title 'httpd.conf - Secure the Pid File.'
  desc 'Secure the Pid File. The PidFile directive sets the file path to the process ID file to which the server records the process id of the server, which is useful for sending a signal to the server process or for checking on the health of the process.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.4.3'
  tag heading: 'System Settings'
  tag remediate: 'no'
  tag action: ''

  describe directory("#{apache_app_dir}") do
      it { should exist }
  end

  httpd_pid_list = command("find #{apache_app_dir} -name httpd.pid").stdout.split("\n")
  httpd_pid_list.map do |pid_file|
    describe file(pid_file) do
      its('owner') { should eq 'eemadmin'}
      its('group') { should eq 'eemgrp'}
      its('mode') { should cmp '0770' }
    end
  end
end

control 'jwsapache-06' do
  impact 1.0
  title 'httpd.conf - Set AllowOverride None'
  desc 'AllowOverrideList Directive, Similar to AllowOverride, but only available in Apache 2.4 as an extension to the controls offered in AllowOverride. When the server finds an .htaccess file (as specified by AccessFileName), it needs to know which directives declared in that file can override earlier configuration directives.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.8.1.8'
  tag heading: 'Protecting OSRs'
  tag remediate: 'update'
  tag action: 'PB1'

  describe directory("#{apache_app_dir}") do
      it { should exist }
  end

  httpd_conf_list = command("find #{apache_app_dir} -name httpd.conf").stdout.split("\n")
  httpd_conf_list.map do |conf_file|
    describe apache_conf(conf_file) do
      its('AllowOverride') { should cmp 'none' }
    end
  end
end

control 'jwsapache-07' do
  impact 1.0
  title 'httpd.conf - Set Timeout to 10'
  desc 'Set the TimeOut to 10 or less. The TimeOut directive controls the maximum time in seconds that Apache HTTP server will wait for an Input/Output call to complete. It is recommended that the TimeOut directive be set to 10 or less.'
  tag requirements: 'I - information'
  tag section: 'AK.6.1.8.1.28'
  tag heading: 'Protecting OSRs'
  tag remediate: 'update'
  tag action: 'PB2'

  describe directory("#{apache_app_dir}") do
      it { should exist }
  end

  httpd_conf_list = command("find #{apache_app_dir} -name httpd.conf").stdout.split("\n")
  httpd_conf_list.map do |conf_file|
    describe apache_conf(conf_file) do
      its('Timeout') { should cmp '10' }
    end
  end
end

control 'jwsapache-08' do
  impact 1.0
  title 'httpd.conf - Document Root Webserver Administrators and Webmaster Groups'
  desc 'This directive sets the directory from which httpd will serve files. Unless matched by a directive like Alias, the server appends the path from the requested URL to the document root to make the path to the document.'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'AK.1.8.4'
  tag heading: 'Protecting Resources - OSRs'
  tag remediate: 'yes'
  tag action: 'May be granted read/write access'

  describe directory("#{apache_web_root}") do
    it { should exist }
    it { should be_owned_by 'hostmstr' }
    its('group') { should eq 'hostmstr' }
    its('mode') { should cmp '0775' }
  end
end

control 'jwsapache-09' do
  impact 1.0
  title 'httpd.conf - Set ServerSignature to Off'
  desc 'Set ServerSignature to Off. Disable the server signatures which generates a signature line as a trailing footer at the bottom of server generated documents such as error pages.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.8.1.26'
  tag heading: 'Protecting OSRs'
  tag remediate: 'update'
  tag action: 'PB3'

  describe directory("#{apache_app_dir}") do
      it { should exist }
  end

  httpd_conf_list = command("find #{apache_app_dir} -name httpd.conf").stdout.split("\n")
  httpd_conf_list.map do |conf_file|
    describe apache_conf(conf_file) do
      its('ServerSignature') { should cmp 'Off' }
    end
  end
end

control 'jwsapache-10' do
  impact 1.0
  title 'httpd.conf - Audit Logs Protection'
  desc 'All logs must be protected from alteration, copying or destruction with measures designed to specifically maintain log data integrity and by limiting access to only authorized individuals.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.2.4'
  tag heading: 'Logging'
  tag remediate: 'yes'
  tag action: ''

  # describe directory("#{apache_app_dir}") do
  #     it { should exist }
  # end

  only_if do
    directory("#{apache_app_dir}").exist?
  end

  httpd_logs_list = command("find #{apache_app_dir} -name logs -type d").stdout.split("\n")
  httpd_logs_list.map do |logs_dir|
    describe directory(logs_dir) do
      it { should be_owned_by 'eemadmin' }
      its('group') { should eq 'eemgrp' }
      its('mode') { should cmp '0700' }
    end
  end
end

# End of controls
