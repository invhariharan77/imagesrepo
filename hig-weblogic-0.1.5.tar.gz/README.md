# HIG WebLogic Application Server InSpec profile

WebLogic Application Server Technical Specification
