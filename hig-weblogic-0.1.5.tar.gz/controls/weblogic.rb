# copyright: 2018, The Authors

title 'HIG - WebLogic Application Server Controls'

control 'weblogic-01' do
  impact 1.0
  title 'Domain Log'
  desc 'For each Domain Log with global security enabled logs'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.1.2.2'
  tag heading: 'Logging'
  tag action: 'no read access for general users'

  # Check the permission (750) against each domain user / dailylog / *domain*
  # => /tech/appl/

  # Rule:
  # foreach "Extended Object Entry:WEBLOGICDOMAIN//**"
  #    ??WEBLOGICDOMAIN?? := @"Name (UI)"@  AND
  #    ??Entry1?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f2 | cut -c 1-3".Out_Put  AND
  #    ??Entry2?? := "find /tech/appl/??Entry1??* -name '*.log' -type f |xargs ls -lt |awk '{print $1}'"  AND
  #    "Command:??Entry2??".Out_Put contains "-rwxr-x---"
  # end  AND
  # "Command:find /tech/appl/Oracle -name '*.log'  -type f |xargs ls -lt |awk '{print $1}'".Out_Put contains "-rwxr-x---"

  describe resource('name') do
  end
end

control 'weblogic-02' do
  impact 1.0
  title 'Authenticate user'
  desc 'Oracle Weblogic must uniquely identify and authenticate users.'
  tag requirements: 'B - baseline'
  tag section: 'DN.6.2.5.2'
  tag heading: 'Privileged Authorizations/Userids'
  tag action: 'Ensure the list of Authentication Providers contains at least one non-Default Authentication Provider LDAP (AD1)'

  # under /tech/appl/<domain_user>/user_projects/<domain*>/config/config.xml
  # => check for <sec:name>WLADMIN_AD1Authenticator</sec:name>
  # Rule:
  # foreach "Extended Object Entry:WEBLOGICDOMAIN//**"
  #    ??WEBLOGICDOMAIN?? := @"Name (UI)"@  AND
  #    ??Entry1?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f1".Out_Put  AND
  #    ??Entry2?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f2 | cut -c 1-3".Out_Put  AND
  #    ??Entry3?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f3".Out_Put  AND
  #    ??Entry4?? := "cat /tech/appl/??Entry2??*/user_projects/??Entry3??/config/config.xml"  AND
  #    "Command:??Entry4??".Message contains (case sensitive) "<sec:name>WLADMIN_AD1Authenticator</sec:name>"  AND
  #    "Command:??Entry4??".Message contains (case sensitive) "<wls:principal>CN=SVCWLADMIN,OU=Service-Accounts,DC=ad1,DC=prod</wls:principal>"
  # end

  describe resource('name') do
  end
end

control 'weblogic-03' do
  impact 1.0
  title '$INSTALLROOT$/* path'
  desc 'OSRs'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.1.8.1'
  tag heading: 'Protecting Resources –OSRs'

  # The $INSTALLROOT$/* and everything under it must be owned by the
  # WebLogic Application Server Process ID or the system administration (root)
  # ID. The owning group must be the WebLogic Application Process Group.
  tag action: ''

  # Rule:
  # if
  #    "Directory:/tech/appl/java" exists
  # then
  #    "Directory:/tech/appl/java"."Permissions (Unix) (Unix)" = "0750"  AND
  #    "Directory:/tech/appl/java"."Group Owner Name" = "wlsuprt"  AND
  #    "Directory:/tech/appl/java"."User Owner Name" = "wlmaster"  AND
  #    if
  #       "Directory:/tech/appl/Oracle" exists
  #    then
  #       "Directory:/tech/appl/Oracle"."Group Owner Name" = "wlsuprt"  AND
  #       "Directory:/tech/appl/Oracle"."Permissions (Unix) (Unix)" = "0750"  AND
  #       "Directory:/tech/appl/Oracle"."User Owner Name" = "wlmaster"
  #    end
  # end  AND
  # "Command:find /tech/appl/Oracle -name '*.log' -type f| xargs ls -lt | awk '{print $1}'".Out_Put matches "-rwxr-x---"  AND
  # "Command:find /tech/appl/Oracle -name '*.bak' -type f| xargs ls -lt | awk '{print $1}'".Out_Put matches "drwxr-x---"  AND
  # "Command:find /tech/appl/Oracle -name '*.back' -type f| xargs ls -lt | awk '{print $1}'".Out_Put matches "drwxr-x---"  AND
  # "Command:find /tech/appl/Oracle -name '*.archive' -type f| xargs ls -lt | awk '{print $1}'".Out_Put matches "drwxr-x---"  AND
  # "Command:find /tech/appl/Oracle -name '*.log'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  # "Command:find /tech/appl/Oracle -name '*.bak'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  # "Command:find /tech/appl/Oracle -name '*.back'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  # "Command:find /tech/appl/Oracle -name '*.archive'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  # foreach "Extended Object Entry:WEBLOGICDOMAIN//**"
  #    ??WEBLOGICDOMAIN?? := @"Name (UI)"@  AND
  #    ??Entry1?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f2 | cut -c 1-3".Out_Put  AND
  #    ??Entry3?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f3".Out_Put  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.log' -type f | xargs ls -lt | awk '{print $1}'".Out_Put matches "-rwxr-x---"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.bak' -type f | xargs ls -lt | awk '{print $1}'".Out_Put matches "drwxr-x---"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.back' -type f | xargs ls -lt | awk '{print $1}'".Out_Put matches "drwxr-x---"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.archive' -type f | xargs ls -lt | awk '{print $1}'".Out_Put matches "drwxr-x---"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.log'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.bak'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.back'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"  AND
  #    "Command:find /tech/appl/??Entry1??* -name '*.archive'  -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains "wlsuprt"
  # end


  describe resource('name') do
  end
end

control 'weblogic-04' do
  impact 1.0
  title '$INSTALLROOT$/* path'
  desc 'OSRs'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.1.8.2'
  tag heading: 'Protecting Resources - OSRs'
  tag action: 'These files must not be owned by a personal userid.'

  # Rule:
  # same as weblogic-03

  describe resource('name') do
  end
end

control 'weblogic-05' do
  impact 1.0
  title '$INSTALLROOT$/* path'
  desc 'OSRs'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.1.8.3'
  tag heading: 'Protecting Resources - OSRs'
  tag action: 'General users are allowed read and execute access unless specified otherwise in this appendix.'

  # Rule:
  # same as weblogic-03

  describe resource('name') do
  end
end

control 'weblogic-06' do
  impact 1.0
  title 'Encryption - Null Cipher'
  desc 'Unencrypted Null Cipher Use - Prevent a null cipher passing data on the wire in clear-text.'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.6.2.1.1'
  tag heading: 'Encryption'
  tag action: 'Under each managed instance-->Configuration--> SSL--> Allow unencrypted Null Cipher must be unchecked'

  #
  # => <ssl> <allow-unencrypted-null-cipher> false </allow-unencrypted-null-cipher> </ssl>

   #  Rules:
   # foreach "Extended Object Entry:WEBLOGICDOMAIN//**"
   #    ??WEBLOGICDOMAIN?? := @"Name (UI)"@  AND
   #    ??Entry1?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f1".Out_Put  AND
   #    ??Entry2?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f2 | cut -c 1-3".Out_Put  AND
   #    ??Entry3?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f3".Out_Put  AND
   #    ??Entry4?? := "cat /tech/appl/??Entry2??*/user_projects/??Entry3??/config/config.xml"  AND
   #    "Command:??Entry4??".Message does not contain (case sensitive) "<allow-unencrypted-null-cipher>true</allow-unencrypted-null-cipher>"
   # end

  describe resource('name') do
  end
end

control 'weblogic-07' do
  impact 0.01
  title 'Message Time Out'
  desc 'Complete message timeout value'
  tag requirements: 'B - baseline'
  tag section: 'DN.6.1.4.4'
  tag heading: 'System Settings'
  tag action: 'Set message timeout under protocols in Administraiton Console to 60 seconds'


  # => <server> <complete-message-timeout>60</complete-message-timeout> </server>

  # Rules:
  # foreach "Extended Object Entry:WEBLOGICDOMAIN//**"
  #    ??WEBLOGICDOMAIN?? := @"Name (UI)"@  AND
  #    ??Entry1?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f1".Out_Put  AND
  #    ??Entry2?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f2 | cut -c 1-3".Out_Put  AND
  #    ??Entry3?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f3".Out_Put  AND
  #    ??Entry4?? := "cat /tech/appl/??Entry2??*/user_projects/??Entry3??/config/config.xml"  AND
  #    (  "Command:??Entry4??".Message does not contain "<complete-message-timeout>"  OR
  #       "Command:??Entry4??".Message contains "<complete-message-timeout>60</complete-message-timeout>"
  #    )
  # end

  describe resource('name') do
  end
end

control 'weblogic-08' do
  impact 0.7
  title 'Production mode'
  desc 'All weblogic instances must run in Production mode.'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.6.1.4.1'
  tag heading: 'System Settings'
  tag action: 'In start scripts of every instance, set PRODUCTION_MODE=true'

  # Rules:
  # foreach "Extended Object Entry:WEBLOGICDOMAIN//**"
  #    ??WEBLOGICDOMAIN?? := @"Name (UI)"@  AND
  #    ??Entry1?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f2 | cut -c 1-3".Out_Put  AND
  #    ??Entry2?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f3 ".Out_Put  AND
  #    ??Entry3?? := "Command:echo ??WEBLOGICDOMAIN?? | cut -d, -f4".Out_Put  AND
  #    ??Entry4?? := "cat /tech/appl/??Entry1??*/user_projects/??Entry2??/scripts/start_??Entry2??_*.sh"  AND
  #    "Command: ??Entry4??".Out_Put contains "PRODUCTION_MODE=""true"""
  # end

  describe resource('name') do
  end
end

control 'weblogic-09' do
  impact 1.0
  title 'Log retention'
  desc 'For each Domain Log with global security enabled logs'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.1.2.3'
  tag heading: 'Logging'
  tag action: 'Logs must be retained for the period specified in the Base Policy - 90 days'

  # Rules: None

  describe resource('name') do
  end
end

control 'weblogic-10' do
  impact 1.0
  title 'OSRs'
  desc '$INSTALLROOT$/* path   <install_root>/<profile_name>/'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'DN.1.8.4'
  tag heading: 'Protecting Resources –OSRs'
  tag action: 'No general user access allowed'

  # Rules: None

  describe resource('name') do
  end
end

# End of controls
