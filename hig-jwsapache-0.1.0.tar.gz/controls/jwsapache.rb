# copyright: 2018, The Authors

title 'HIG - IBM Red Hat JWS Apache httpd Controls'

control 'jwsapache-01' do
  impact 1.0
  title 'Web Server ID - Unique group'
  desc 'An ID which runs the web server'
  tag requirements: 'B - baseline'
  tag section: 'AK.1.7.6'
  tag heading: 'Identify and Authenticate Users'
  tag remediate: 'none'

  # Create a new, unique group that the server will run as.
  tag action: 'Create a new, unique group that the server will run as.'

  # Rules:
  # Unix Users.Unix User:/eemadmin exists  AND
  # Unix Groups.Unix Group:/eemgrp exists  AND
  # Unix Users.Unix User:/hostmstr exists  AND
  # Unix Groups.Unix Group:/hostmstr exists

  describe group('eemgrp') do
    it { should exist }
  end

  describe group('hostmstr') do
    it { should exist }
  end
end

control 'jwsapache-02' do
  impact 1.0
  title 'Web Server ID - Unique user'
  desc 'An ID which runs the web server'
  tag requirements: 'B - baseline'
  tag section: 'AK.1.7.7'
  tag heading: 'Identify and Authenticate Users'
  tag remediate: 'none'

  # Create new, unique local userid that the web server will run as, with the default group being the one created above
  tag action: 'Create new, unique local userid that the web server will run as, with the default group being the one created above'

  # Rules:
  # Unix Users.Unix User:/eemadmin exists  AND
  # Unix Groups.Unix Group:/eemgrp exists  AND
  # Unix Users.Unix User:/hostmstr exists  AND
  # Unix Groups.Unix Group:/hostmstr exists

  describe user('eemadmin') do
    it { should exist }
    its('group') { should eq 'eemgrp' }
  end

  describe user('hostmstr') do
    it { should exist }
    its('group') { should eq 'hostmstr' }
  end

  describe processes('httpd') do
    its('users') { should include 'eemadmin' }
  end
end

control 'jwsapache-03' do
  impact 1.0
  title 'httpd.conf - enable log module'
  desc 'Enable the Log Config Module. The log_config module provides for flexible logging of client requests, and provides for the configuration of the information in each log.    Rationale: Logging is critical for monitoring usage and potential abuse of your web server.  To configure the web server logging using the log_format directive this module is required.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.2.1'
  tag heading: 'Logging'
  tag remediate: 'none'

  # PERFORM either one of the following:
  # 1. For source builds with static modules run the Apache ./configure script including only the modules needed in the --enable-modules= configure script options.
  # 2. For dynamically loaded modules, confirm or add the below module directive(s) in the httpd.conf file or any sub-config loaded from httpd.conf.
  # LoadModule log_config_module modules/mod_log_config.so
  # Default is dependent on distribution and installation method, but commonly this is default enabled.
  #
  tag action: ''

  # Rules:
  #   if
  #    "Command:find /tech/jws/sites -name '*.pid' -type f |xargs ls -lt |awk '{print $9}'".Out_Put contains (case sensitive) "httpd.pid"
  # then
  #    "Command:find /tech/jws/sites -name '*.pid' -type f |xargs ls -lt |awk '{print $3}'".Out_Put contains (case sensitive) "eemadmin"  AND
  #    "Command:find /tech/jws/sites -name '*.pid' -type f |xargs ls -lt |awk '{print $4}'".Out_Put contains (case sensitive) "eemgrp"
  # end  AND
  # describe file('/run/httpd/httpd.pid.1') do
  #   its('owner') { should eq 'eemadmin'}
  #   its('group') { should eq 'eemgrp'}
  # end

  # if
  #    "File:/tech/jws/sites/common/conf/modules.conf" exists
  # then
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule log_config_module /tech/jws/3.0.3/httpd/modules/mod_log_config.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule dir_module /tech/jws/3.0.3/httpd/modules/mod_dir.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule mime_module /tech/jws/3.0.3/httpd/modules/mod_mime.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule authz_core_module /tech/jws/3.0.3/httpd/modules/mod_authz_core.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule access_compat_module /tech/jws/3.0.3/httpd/modules/mod_access_compat.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule unixd_module /tech/jws/3.0.3/httpd/modules/mod_unixd.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule negotiation_module /tech/jws/3.0.3/httpd/modules/mod_negotiation.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule alias_module /tech/jws/3.0.3/httpd/modules/mod_alias.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule setenvif_module /tech/jws/3.0.3/httpd/modules/mod_setenvif.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule env_module /tech/jws/3.0.3/httpd/modules/mod_env.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule proxy_module /tech/jws/3.0.3/httpd/modules/mod_proxy.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule proxy_http_module /tech/jws/3.0.3/httpd/modules/mod_proxy_http.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule headers_module /tech/jws/3.0.3/httpd/modules/mod_headers.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule reqtimeout_module /tech/jws/3.0.3/httpd/modules/mod_reqtimeout.so"  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf".Contents contains (case sensitive) "LoadModule rewrite_module /tech/jws/3.0.3/httpd/modules/mod_rewrite.so"
  # end  AND
  # TODO: To do a recursive search for all the .conf files (under directory: /tech/jws/3.0.3/httpd/conf.modules.d)
  # describe file('/opt/jws-3.0/httpd/conf/modules.conf') do
  #   it { should exist }
  #   its('content') { should be_in 'LoadModule log_config_module /tech/jws/3.0.3/httpd/modules/mod_log_config.so' }
  # end

  describe apache_conf('/opt/jws-3.0/httpd/conf/modules.conf') do
    its('LoadModule') { should include 'log_config_module /tech/jws/3.0.3/httpd/modules/mod_log_config.so' }
  end


  # foreach "Extended Object Entry:CONFIGFILE//**":question
  #    ??CONFIGFILE?? := @"Name (UI)"@  AND
  #    "File:/??CONFIGFILE??".Contents contains "Include /tech/jws/sites/common/conf/*.conf"  AND
  #    "File:/??CONFIGFILE??".Contents contains (case sensitive) "ServerRoot"
  # end
  # command('find /opt/jws-3.0/httpd/conf.d/*.conf -type f').stdout.split.each do |fname|
  #   describe file(fname) do
  #     its('owner') { should eq 'root' }
  #     # its('content') { should cmp 'Include /tech/jws/sites/common/conf/*.conf' }
  #     # its('content') { should cmp 'ServerRoot' }
  #   end
  # end

end

control 'jwsapache-04' do
  impact 1.0
  title 'httpd.conf - Run the Apache Web Server as a non-root user'
  desc 'Run the Apache Web Server as a non-root user. Although Apache typically is started with root privileges in order to listen on port 80 and 443, it can and should run as another non-root user in order to perform the web services.  The Apache User and Group directives are used to designate the user and group to be used'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.4.1'
  tag heading: 'System Settings'
  tag remediate: 'none'

  # PERFORM the following:
  # If the Apache user and group do not already exist, create the account and group as a unique system account:
  # # groupadd –r apache
  # # useradd apache -r -g apache -d /var/www -s /sbin/nologin
  #
  # Configure the Apache user and group in the Apache configuration file httpd.conf:
  # User eemadmin
  # Group eemgrp
  # Default is dependent on distribution and installation method.
  #
  tag action: 'If the Apache user and group do not already exist, create the account and group as a unique system account'

  # Rules:
  # "Directory:/tech/jws/sites"."User Owner Name" = "eemadmin"  AND
  # "Directory:/tech/jws/sites"."Group Owner Name" = "eemgrp"  AND
  # "Directory:/tech/jws/sites"."Permissions (Unix) (Unix)" = "0770"  AND
  # "Unix Users.Unix User:/eemadmin" exists  AND
  # "Unix Users.Unix User:/hostmstr" exists  AND
  # "Unix Groups.Unix Group:/eemgrp" exists  AND
  # "Unix Groups.Unix Group:/hostmstr" exists

  describe processes('httpd') do
    its('users') { should include 'eemadmin' }
    # its('commands') { should include '/usr/sbin/httpd -DFOREGROUND' }
    its('commands') { should include '/opt/jws-3.0/httpd/sbin/httpd -f /opt/jws-3.0/httpd/conf/httpd.conf -E /opt/jws-3.0/httpd/logs/httpd.log -k start' }
  end

  describe apache_conf('/opt/jws-3.0/httpd/conf/httpd.conf') do
    its('User') { should cmp 'eemadmin' }
    its('Group') { should cmp 'eemgrp' }
  end

end

control 'jwsapache-05' do
  impact 1.0
  title 'httpd.conf - Secure the Pid File.'
  desc 'Secure the Pid File. The PidFile directive sets the file path to the process ID file to which the server records the process id of the server, which is useful for sending a signal to the server process or for checking on the health of the process.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.4.3'
  tag heading: 'System Settings'
  tag remediate: 'none'

  # VERIFY:
  # 1. Find the directory in which the PidFile would be created. The default value for community installation is the ServerRoot/logs directory. The default directory for JWS 3.x is $JWS_HOME/httpd/run
  # 2. Modify the directory if the PidFile is in a directory within the Apache DocumentRoot
  # 3. Verify the Pidfile is protected by permssions of 600 and ownership of applicaiton id.
  # Default is dependent on distribution and installation method.
  #
  tag action: ''

  # Rules:
  # if
  #    "Command:ps -ef|grep httpd |grep eemadmin".Out_Put contains "httpd"  AND
  #    "Command:ps -ef|grep httpd |grep eemadmin".Out_Put matches "eemadmin"
  # then
  #    "Command:ps -ef|grep httpd |grep eemadmin".Out_Put contains "/tech/jws/sites/"
  # end

  # describe file('/run/httpd/httpd.pid') do
  describe file('/opt/jws-3.0/httpd/run/httpd.pid') do
    its('owner') { should eq 'eemadmin'}
    its('group') { should eq 'eemgrp'}
    its('mode') { should cmp '0600' }
  end
end

control 'jwsapache-06' do
  impact 1.0
  title 'httpd.conf - Set AllowOverride None'
  desc 'AllowOverrideList Directive, Similar to AllowOverride, but only available in Apache 2.4 as an extension to the controls offered in AllowOverride. When the server finds an .htaccess file (as specified by AccessFileName), it needs to know which directives declared in that file can override earlier configuration directives.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.8.1.8'
  tag heading: 'Protecting OSRs'
  tag remediate: 'partial'

  # PERFORM the following:
  # 1. Remove all occurrences of AllowOverrideList or
  # 2. Set all occurrences of AllowOverrideList to None
  # Default:	AllowOverrideList None
  #
  tag action: 'PB1'

  # Rules:
  # if
  #    "File:/tech/jws/sites/common/conf/webcheck.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/00-mpm.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/sec_headers.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "Alias ""/webcheck"" ""/tech/web/webcheck"""  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "AllowOverride None"  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "SetEnvIf Request_URI ""/webcheck"" no_log"  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "<Directory ""/tech/web/webcheck"">"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "LimitRequestFields 100"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "LimitRequestLine 512"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RequestReadTimeout header=20-40,MinRate=500 body=20,MinRate=500"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "KeepAlive On"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "KeepAliveTimeout 15"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "MaxKeepAliveRequests 100"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "Timeout 10"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "ServerSignature Off"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "TraceEnable off"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "ServerTokens Prod"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteEngine On"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteCond %{THE_REQUEST} !HTTP/1\.1$"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteRule .* - [F]"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteOptions Inherit"
  # then
  #    foreach "Extended Object Entry:CONFIGFILE//**"
  #       ??CONFIGFILE?? := @"Name (UI)"@  AND
  #       "File:/??CONFIGFILE??".Contents contains "Include /tech/jws/sites/common/conf/*.conf"  AND
  #       "File:/??CONFIGFILE??".Contents contains (case sensitive) "ServerRoot"
  #    end
  # end

  describe apache_conf('/opt/jws-3.0/httpd/conf/httpd.conf') do
    its('AllowOverride') { should cmp 'None' }
  end
end

control 'jwsapache-07' do
  impact 0.01
  title 'httpd.conf - Set Timeout to 10'
  desc 'Set the TimeOut to 10 or less. The TimeOut directive controls the maximum time in seconds that Apache HTTP server will wait for an Input/Output call to complete. It is recommended that the TimeOut directive be set to 10 or less.'
  tag requirements: 'I - information'
  tag section: 'AK.6.1.8.1.28'
  tag heading: 'Protecting OSRs'
  tag remediate: 'partial'

  # PERFORM the following:
  # Add or modify the Timeout directive in the Apache configuration to have a value of 10 seconds or shorter.
  # Timeout 10
  # Commnity Default: TimeOut 300
  # JWS 3.x Default: Timout 120
  #
  tag action: 'PB2'

  # Rules:
  # if
  #    "File:/tech/jws/sites/common/conf/webcheck.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/00-mpm.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/modules.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/sec_headers.conf" exists  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "Alias ""/webcheck"" ""/tech/web/webcheck"""  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "AllowOverride None"  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "SetEnvIf Request_URI ""/webcheck"" no_log"  AND
  #    "File:/tech/jws/sites/common/conf/webcheck.conf".Contents contains (case sensitive) "<Directory ""/tech/web/webcheck"">"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "LimitRequestFields 100"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "LimitRequestLine 512"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RequestReadTimeout header=20-40,MinRate=500 body=20,MinRate=500"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "KeepAlive On"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "KeepAliveTimeout 15"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "MaxKeepAliveRequests 100"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "Timeout 10"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "ServerSignature Off"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "TraceEnable off"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "ServerTokens Prod"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteEngine On"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteCond %{THE_REQUEST} !HTTP/1\.1$"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteRule .* - [F]"  AND
  #    "File:/tech/jws/sites/common/conf/techspec.conf".Contents contains (case sensitive) "RewriteOptions Inherit"
  # then
  #    foreach "Extended Object Entry:CONFIGFILE//**"
  #       ??CONFIGFILE?? := @"Name (UI)"@  AND
  #       "File:/??CONFIGFILE??".Contents contains "Include /tech/jws/sites/common/conf/*.conf"  AND
  #       "File:/??CONFIGFILE??".Contents contains (case sensitive) "ServerRoot"
  #    end
  # end

  describe apache_conf('/opt/jws-3.0/httpd/conf/httpd.conf') do
    its('Timeout') { should cmp '120' }
  end
end

control 'jwsapache-08' do
  impact 0.7
  title 'httpd.conf - Document Root Webserver Administrators and Webmaster Groups'
  desc 'This directive sets the directory from which httpd will serve files. Unless matched by a directive like Alias, the server appends the path from the requested URL to the document root to make the path to the document.'
  tag requirements: 'S - healthcheck and baseline'
  tag section: 'AK.1.8.4'
  tag heading: 'Protecting Resources - OSRs'
  tag remediate: 'none'

  # May be granted read/write access
  #
  tag action: ''

  # Rules:
  # if
  #    "Directory:/tech/web" exists
  # then
  #    "Directory:/tech/web"."Permissions (Unix) (Unix)" = "0775"  AND
  #    "Directory:/tech/web"."User Owner Name" = "hostmstr"  AND
  #    "Directory:/tech/web"."Group Owner Name" = "hostmstr"
  # end

  describe directory('/tech/web') do
    it { should exist }
    it { should be_owned_by 'hostmstr' }
    its('group') { should eq 'hostmstr' }
    its('mode') { should cmp '0775' }
  end
end

control 'jwsapache-09' do
  impact 1.0
  title 'httpd.conf - Set ServerSignature to Off'
  desc 'Set ServerSignature to Off. Disable the server signatures which generates a signature line as a trailing footer at the bottom of server generated documents such as error pages.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.8.1.26'
  tag heading: 'Protecting OSRs'
  tag remediate: 'partial'

  # PERFORM the following:
  # Add or modify the ServerSignature directive as shown below to have the value of
  # ServerSignature Off
  # Default: ServerSignature Off
  #
  tag action: 'PB3'

  # Rules: None

  describe apache_conf('/opt/jws-3.0/httpd/conf/httpd.conf') do
    its('ServerSignature') { should cmp 'Off' }
  end
end

control 'jwsapache-10' do
  impact 0.4
  title 'httpd.conf - Audit Logs Protection'
  desc 'All logs must be protected from alteration, copying or destruction with measures designed to specifically maintain log data integrity and by limiting access to only authorized individuals.'
  tag requirements: 'B - baseline'
  tag section: 'AK.6.1.2.4'
  tag heading: 'Logging'
  tag remediate: 'none'

  # Perform the following to restrict access to apache log files:
  # 1. Set the ownership of the $APACHE_HOME/logs to eemadmin:eemgrp or root:root or similar chosen user/group specific to apache only.
  # 2. Remove read, write, and execute permissions for the world
  # # chown $USER_NAME:$GROUP_NAME $APACHE_PREFIX/logs
  # # chmod g-w o-rwx $APACHE_PREFIX/logs
  #
  tag action: ''

  # Rules: None

  describe directory('/opt/jws-3.0/httpd/logs') do
    it { should be_owned_by 'eemadmin' }
    its('group') { should eq 'eemgrp' }
    its('mode') { should cmp '0760' }
  end
end

# End of controls
